<p style="text-transform: capitalize;">Hello {{$data['name']}},</p> 
<p>Thank you for placing your order with Bubblzz!</p>
<p>Your order will be delivered within 2-3 days,</p>
<p>A representative will contact you to arrange delivery.,</p>
<p>Bubblz Team.</p>